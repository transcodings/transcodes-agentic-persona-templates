---
name: explain-transcodes
description: Give the product map — use when asked what Transcodes is, what a Persona changes, or how this team uses it, before or after they have a project folder.
---

# Prerequisites

- Language of the request.
- Whether they have already Applied a Persona to a folder.

# Steps

1. One line: set a Persona and Knowledge Base in Transcodes Desktop, Apply them into the project folder, then every AI opened in that folder follows the same standard.
2. Before any feature list, explain with two roles on the same request. Do not skip this.

   Same request: “Make the onboarding button stand out.”

   **Designer Persona** — there is no Designer template. They create this with Add Persona → Set up yourself.

   - Instruction / AGENTS.md: a product designer. Designs the whole state set. Reaches for an existing component and its tokens first.
   - Guideline / rule.md: use tokens for colour and spacing. Never hardcode a hex or a pixel value a token already covers.
   - Skill / SKILL.md: `design-review`. Walk empty, loading, error. Report blocking / should-fix / polish, each with the file and the fix.
   - Knowledge Base they would link: design tokens, component names, accessibility target.
   - What the AI actually does: names the token, the missing state, and the label. It does not write a PRD.

   **Planner Persona** — there is no Planner template. They create this with Add Persona → Set up yourself.

   - Instruction / AGENTS.md: a product planner. Turns a request into a decision, not a mock.
   - Guideline / rule.md: every spec includes problem, user, success metric, and non-goals. Never invent a ship date.
   - Skill / SKILL.md: `write-spec`. Draft problem → options → recommendation → open questions.
   - Knowledge Base they would link: past specs, who the product is for, pricing facts.
   - What the AI actually does: writes the decision and the open questions. It does not pick a token or restyle the button.

   One contrast line: same sentence, two Personas, two jobs. That is the value. A third Persona would answer a third way — say so only if they ask.

3. After the example, explain the part they asked, then keep going until they are installing a Persona and a linked Knowledge Base. Order:
   - Desktop app — the library. Sidebar: Personas, Knowledge Base, Organization, Settings.
   - Persona — Instruction, Guideline, Skill. Point back to the Designer and Planner fill-in above.
   - Knowledge Base — documents and contents with required keywords, linked to a Persona.
   - Apply to a project — the required step. Folder + AIs + This workspace only → the three Advanced checks → restart → check question. Apply the Designer Persona to the design repo, the Planner Persona to the spec folder. Same AI, different folder, different job. The save check lets that chat update the linked Knowledge Base. The improve check lets that chat tune the Instruction and Guidelines. Both need Apply.
   - Versioning — Organization tables. Personas get revisions. Knowledge Bases get one tagged latest copy.
   - Organization — members, invites, plan. Standard for cloud and seats.
   - Plugin — Desktop Settings → Plugin → Install on each AI, restart that AI, then `/transcodes` (Claude, Cursor, Antigravity) or `$transcodes` (ChatGPT).
4. Plans: Free is unlimited local Personas and Knowledge Bases, and local Apply. Standard is cloud sync, team invites, AI document summaries, and AI Persona edits. Standard is $6 per member per month. Do not invent another price.
5. How To Use in the profile menu has the same seven chapters, with videos. Mention it as a picture they can open later. Do not send them there instead of explaining.
6. If they have no project Apply yet, walk apply-persona now: Persona, linked Knowledge Base, folder, AIs, Apply to Workspace. Do not end on a map.

# Gotchas

- Saved in Desktop ≠ used in the project. Apply is the line.
- Do not present Designer or Planner as a catalog template. Both are Set up yourself. The catalog is Guide, Starter, Card News Creator, Presentation Deck Kit, and Landing SEO GEO AEO Checker.
- This guide does not cover Guard, Admin API, or the authentication SDK.

# Output

**Deliverable** — One everyday request, spelled out for the Persona you are explaining, then the install path: that Persona, its Knowledge Base, the project folder, and Apply.
**Done when** — They know which Persona and Knowledge Base to install, and which folder still needs Apply.
